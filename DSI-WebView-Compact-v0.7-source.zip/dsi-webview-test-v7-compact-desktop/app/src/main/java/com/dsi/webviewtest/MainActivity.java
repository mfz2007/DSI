package com.dsi.webviewtest;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Landscape desktop-layout WebView diagnostic. */
public final class MainActivity extends Activity {
    private static final String START_URL = "https://chatgpt.com/";
    private static final String DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36";
    private static final String DESKTOP_LAYOUT_SCRIPT =
            "(function(){"
                    + "if(window.__dsiCompactDesktop)return;window.__dsiCompactDesktop=true;"
                    + "function imp(e,p,v){if(e)e.style.setProperty(p,v,'important');}"
                    + "var style=document.getElementById('dsi-desktop-style');"
                    + "if(!style){style=document.createElement('style');style.id='dsi-desktop-style';document.head.appendChild(style);}"
                    + "style.textContent=`@media (orientation:landscape){"
                    + "textarea,[contenteditable='true']{min-height:28px!important;max-height:88px!important;padding-top:5px!important;padding-bottom:5px!important;line-height:1.35!important;}"
                    + "}`;"
                    + "function compactComposer(){"
                    + "var box=document.querySelector('textarea')||document.querySelector('[contenteditable=\\\"true\\\"][role=\\\"textbox\\\"]');"
                    + "if(!box)return;"
                    + "imp(box,'min-height','28px');imp(box,'height','40px');imp(box,'max-height','88px');"
                    + "imp(box,'padding-top','5px');imp(box,'padding-bottom','5px');"
                    + "var p=box;"
                    + "for(var i=0;i<8&&p;i++,p=p.parentElement){"
                    + "var r=p.getBoundingClientRect();"
                    + "if(r.width>window.innerWidth*.35&&r.height>20&&r.height<260){"
                    + "imp(p,'min-height','0px');imp(p,'max-height','108px');"
                    + "if(i>0){imp(p,'padding-top','4px');imp(p,'padding-bottom','4px');}"
                    + "}"
                    + "if(p.tagName==='FORM')break;"
                    + "}"
                    + "}"
                    + "function compactSidebar(){"
                    + "var side=document.querySelectorAll(\"nav,aside,[role='navigation'],[data-testid*='sidebar'],[class*='sidebar'],[class*='Sidebar']\");"
                    + "for(var i=0;i<side.length;i++){var e=side[i],r=e.getBoundingClientRect();"
                    + "if(r.left<=8&&r.width>160&&r.width<window.innerWidth*.6&&r.height>window.innerHeight*.45){"
                    + "imp(e,'width','72px');imp(e,'min-width','72px');imp(e,'max-width','72px');imp(e,'flex-basis','72px');imp(e,'overflow-x','hidden');"
                    + "}}"
                    + "if(!window.__dsiSidebarClicked){var nodes=document.querySelectorAll('button,[role=button]');"
                    + "for(var j=0;j<nodes.length;j++){var n=nodes[j],t=((n.getAttribute('aria-label')||'')+' '+(n.getAttribute('title')||'')+' '+(n.getAttribute('data-testid')||''));"
                    + "if(/close sidebar|关闭侧边栏|hide sidebar|收起侧边栏|collapse sidebar/i.test(t)){n.click();window.__dsiSidebarClicked=true;break;}}}"
                    + "}"
                    + "compactComposer();compactSidebar();"
                    + "if(document.body){new MutationObserver(function(){compactComposer();compactSidebar();}).observe(document.body,{childList:true,subtree:true});}"
                    + "})();";
    private static final int GOLD = Color.rgb(208, 168, 92);
    private static final int BG = Color.rgb(9, 12, 11);
    private FrameLayout root;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        setContentView(root);
        try {
            configureWindow();
            showNativeScreen();
        } catch (Throwable error) {
            showError("原生 Activity 启动异常", error);
        }
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.BLACK);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        hideSystemBars();
    }

    private void hideSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void showNativeScreen() {
        root.removeAllViews();
        FrameLayout panel = new FrameLayout(this);
        panel.setBackgroundColor(BG);

        TextView status = new TextView(this);
        status.setText("DSI WebView Test 0.7.0\n\n紧凑电脑网页排版测试\n尚未创建 WebView");
        status.setTextColor(GOLD);
        status.setTextSize(16f);
        status.setGravity(Gravity.CENTER);
        status.setPadding(32, 32, 32, 32);
        panel.addView(status, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        Button start = new Button(this);
        start.setText("创建 WebView 并加载 ChatGPT");
        start.setOnClickListener(v -> launchWebView());
        FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        buttonParams.bottomMargin = 72;
        panel.addView(start, buttonParams);
        root.addView(panel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private void launchWebView() {
        try {
            root.removeAllViews();
            webView = new WebView(this);
            webView.setBackgroundColor(BG);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            // Ask ChatGPT to render its desktop layout instead of the narrow
            // Android WebView layout. The Activity itself is locked to landscape.
            settings.setUserAgentString(DESKTOP_USER_AGENT);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(true);
            settings.setSupportMultipleWindows(false);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (url != null && url.startsWith("https://chatgpt.com")) {
                        applyDesktopLayout(view);
                        view.postDelayed(() -> applyDesktopLayout(view), 700L);
                        view.postDelayed(() -> applyDesktopLayout(view), 1800L);
                        view.postDelayed(() -> applyDesktopLayout(view), 3500L);
                    }
                }

                @Override
                public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                    try {
                        root.removeView(view);
                        view.destroy();
                    } catch (Throwable ignored) {
                    }
                    showErrorText("WebView 渲染进程退出\n请记录这句话和手机型号");
                    return true;
                }
            });
            root.addView(webView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            webView.loadUrl("about:blank");
            webView.postDelayed(() -> {
                if (webView != null) webView.loadUrl(START_URL);
            }, 500L);
        } catch (Throwable error) {
            showError("WebView 创建或初始化异常", error);
        }
    }

    private void applyDesktopLayout(WebView view) {
        try {
            view.evaluateJavascript(DESKTOP_LAYOUT_SCRIPT, null);
        } catch (Throwable ignored) {
        }
    }

    private void showError(String title, Throwable error) {
        String detail = error.getClass().getSimpleName();
        if (error.getMessage() != null && !error.getMessage().isEmpty()) {
            detail += "\n" + error.getMessage();
        }
        showErrorText(title + "\n\n" + detail);
    }

    private void showErrorText(String text) {
        root.removeAllViews();
        TextView message = new TextView(this);
        message.setText(text);
        message.setTextColor(GOLD);
        message.setTextSize(15f);
        message.setGravity(Gravity.CENTER);
        message.setPadding(32, 32, 32, 32);
        message.setBackgroundColor(BG);
        root.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.destroy();
            } catch (Throwable ignored) {
            }
            webView = null;
        }
        super.onDestroy();
    }
}
