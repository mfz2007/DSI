package com.dsi.webviewtest;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

/** Landscape desktop-layout WebView diagnostic. */
public final class MainActivity extends Activity {
    private static final String START_URL = "https://chatgpt.com/";
    private static final String DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36";
    private static final String DESKTOP_LAYOUT_SCRIPT =
            "(function(){"
                    + "if(window.__dsiCodexLayout)return;window.__dsiCodexLayout=true;"
                    + "function imp(e,p,v){if(e)e.style.setProperty(p,v,'important');}"
                    + "var style=document.getElementById('dsi-desktop-style');"
                    + "if(!style){style=document.createElement('style');style.id='dsi-desktop-style';document.head.appendChild(style);}"
                    + "style.textContent=`@media (orientation:landscape){"
                    + "textarea,[contenteditable='true']{min-height:28px!important;max-height:88px!important;padding-top:5px!important;padding-bottom:5px!important;line-height:1.35!important;}"
                    + "}`;"
                    + "function findSide(){var a=document.querySelectorAll(\"nav,aside,[role='navigation'],[data-testid*='sidebar'],[class*='sidebar'],[class*='Sidebar']\"),best=null,bw=0;"
                    + "for(var i=0;i<a.length;i++){var r=a[i].getBoundingClientRect();if(r.left<=8&&r.width>160&&r.width<window.innerWidth*.6&&r.height>window.innerHeight*.45&&r.width>bw){best=a[i];bw=r.width;}}return best;}"
                    + "function clickSidebarToggle(){if(window.__dsiSideToggleDone)return;var side=findSide();if(!side)return;var sr=side.getBoundingClientRect(),b=side.querySelectorAll('button,[role=button]'),best=null,br=0;"
                    + "for(var i=0;i<b.length;i++){var r=b[i].getBoundingClientRect();if(r.top<150&&r.width<120&&r.height<120&&r.right>sr.right-140&&r.right>br){best=b[i];br=r.right;}}"
                    + "if(best){best.click();window.__dsiSideToggleDone=true;}}"
                    + "function findComposer(){var q=document.querySelectorAll('textarea,[contenteditable=\\\"true\\\"],[data-placeholder],[placeholder],[aria-label]'),best=null,bw=0;"
                    + "for(var i=0;i<q.length;i++){var e=q[i],r=e.getBoundingClientRect(),s=((e.getAttribute('placeholder')||'')+' '+(e.getAttribute('data-placeholder')||'')+' '+(e.getAttribute('aria-label')||''));"
                    + "if(r.width>window.innerWidth*.25&&r.height>8&&r.bottom>0&&r.top<window.innerHeight&&/询问|ask chatgpt|message|prompt/i.test(s)&&r.width>bw){best=e;bw=r.width;}}"
                    + "if(best)return best;var a=document.querySelectorAll('div,p');for(var j=0;j<a.length;j++){var x=a[j],rr=x.getBoundingClientRect(),tt=(x.textContent||'').trim();if(tt.length>0&&tt.length<40&&/询问\\s*ChatGPT|ask\\s*ChatGPT/i.test(tt)&&rr.width>window.innerWidth*.25&&rr.height>8){return x;}}return null;}"
                    + "function compactComposer(){var box=findComposer();if(!box)return;"
                    + "imp(box,'min-height','28px');imp(box,'height','40px');imp(box,'max-height','88px');imp(box,'padding-top','5px');imp(box,'padding-bottom','5px');"
                    + "var p=box,outer=null;for(var i=0;i<8&&p;i++,p=p.parentElement){var r=p.getBoundingClientRect();if(i>0&&r.width>window.innerWidth*.45&&r.height>=70&&r.height<240){outer=p;break;}if(p.tagName==='FORM')break;}"
                    + "if(outer){imp(outer,'height','76px');imp(outer,'min-height','0px');imp(outer,'max-height','76px');imp(outer,'padding-top','4px');imp(outer,'padding-bottom','4px');}}"
                    + "function apply(){compactComposer();clickSidebarToggle();}"
                    + "apply();setTimeout(apply,700);setTimeout(apply,1600);setTimeout(apply,3000);"
                    + "if(document.body){new MutationObserver(function(){compactComposer();}).observe(document.body,{childList:true,subtree:true});}"
                    + "})();";
    private static final String NATIVE_SHELL_COLLAPSE_SCRIPT =
            "(function(){"
                    + "if(window.__dsiNativeShellCollapse)return;window.__dsiNativeShellCollapse=true;"
                    + "var a=document.querySelectorAll(\"nav,aside,[role='navigation'],[data-testid*='sidebar'],[class*='sidebar'],[class*='Sidebar']\"),side=null,bw=0;"
                    + "for(var i=0;i<a.length;i++){var r=a[i].getBoundingClientRect();if(r.left<=8&&r.width>160&&r.width<window.innerWidth*.6&&r.height>window.innerHeight*.45&&r.width>bw){side=a[i];bw=r.width;}}"
                    + "if(!side)return;var sr=side.getBoundingClientRect(),b=side.querySelectorAll('button,[role=button]'),best=null,br=0;"
                    + "for(var j=0;j<b.length;j++){var x=b[j].getBoundingClientRect();if(x.top<150&&x.width<120&&x.height<120&&x.right>sr.right-140&&x.right>br){best=b[j];br=x.right;}}"
                    + "if(best)best.click();"
                    + "})();";

    private static final int GOLD = Color.rgb(208, 168, 92);
    private static final int BG = Color.rgb(9, 12, 11);
    private FrameLayout root;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        setContentView(root);
        try {
            configureWindow();
            showNativeScreen();
        } catch (Throwable error) {
            showError("原生 Activity 启动异常", error);
        }
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.BLACK);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        hideSystemBars();
    }

    private void hideSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void showNativeScreen() {
        root.removeAllViews();
        FrameLayout panel = new FrameLayout(this);
        panel.setBackgroundColor(BG);

        TextView status = new TextView(this);
        status.setText("DSI WebView Test 0.10.0\n\nDSI 原生 Codex 外壳测试\n尚未创建 WebView");
        status.setTextColor(GOLD);
        status.setTextSize(16f);
        status.setGravity(Gravity.CENTER);
        status.setPadding(32, 32, 32, 32);
        panel.addView(status, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        Button start = new Button(this);
        start.setText("创建 WebView 并加载 ChatGPT");
        start.setOnClickListener(v -> launchWebView());
        FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        buttonParams.bottomMargin = 72;
        panel.addView(start, buttonParams);
        root.addView(panel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private void launchWebView() {
        try {
            root.removeAllViews();
            webView = new WebView(this);
            webView.setBackgroundColor(BG);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            // Ask ChatGPT to render its desktop layout instead of the narrow
            // Android WebView layout. The Activity itself is locked to landscape.
            settings.setUserAgentString(DESKTOP_USER_AGENT);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(true);
            settings.setSupportMultipleWindows(false);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (url != null && url.startsWith("https://chatgpt.com")) {
                        applyDesktopLayout(view);
                        view.postDelayed(() -> applyDesktopLayout(view), 700L);
                        view.postDelayed(() -> applyDesktopLayout(view), 1800L);
                        view.postDelayed(() -> applyDesktopLayout(view), 3500L);
                    }
                }

                @Override
                public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                    try {
                        root.removeView(view);
                        view.destroy();
                    } catch (Throwable ignored) {
                    }
                    showErrorText("WebView 渲染进程退出\n请记录这句话和手机型号");
                    return true;
                }
            });
            root.addView(webView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            root.post(this::buildNativeShell);
            webView.loadUrl("about:blank");
            webView.postDelayed(() -> {
                if (webView != null) webView.loadUrl(START_URL);
            }, 500L);
        } catch (Throwable error) {
            showError("WebView 创建或初始化异常", error);
        }
    }

    private void applyDesktopLayout(WebView view) {
        try {
            view.evaluateJavascript(NATIVE_SHELL_COLLAPSE_SCRIPT, null);
        } catch (Throwable ignored) {
        }
    }

    private void buildNativeShell() {
        if (root.findViewWithTag("dsi-native-shell") != null) return;
        int width = root.getWidth();
        int height = root.getHeight();
        if (width < 400 || height < 240) {
            root.post(this::buildNativeShell);
            return;
        }

        int railWidth = Math.max(88, Math.round(width * 0.075f));
        int topHeight = Math.max(72, Math.round(height * 0.13f));
        int composerHeight = Math.max(92, Math.round(height * 0.16f));

        FrameLayout shell = new FrameLayout(this);
        shell.setTag("dsi-native-shell");
        shell.setClickable(false);
        root.addView(shell, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        LinearLayout rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        rail.setGravity(Gravity.CENTER_HORIZONTAL);
        rail.setBackgroundColor(Color.rgb(5, 5, 5));
        FrameLayout.LayoutParams railParams = new FrameLayout.LayoutParams(
                railWidth, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.LEFT | Gravity.TOP);
        shell.addView(rail, railParams);

        TextView railBrand = shellText("DSI", 14f, GOLD);
        railBrand.setGravity(Gravity.CENTER);
        rail.addView(railBrand, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, topHeight));
        addRailIcon(rail, "⌂", null);
        addRailIcon(rail, "✎", v -> runPageAction("new chat"));
        addRailIcon(rail, "▧", v -> runPageAction("image"));
        addRailIcon(rail, "⊙", v -> runPageAction("plugin"));
        addRailIcon(rail, "◈", null);
        LinearLayout.LayoutParams railSpacer = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        rail.addView(new View(this), railSpacer);
        addRailIcon(rail, "⚙", v -> runPageAction("settings"));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(18, 0, 18, 0);
        top.setBackgroundColor(Color.rgb(5, 5, 5));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, topHeight, Gravity.TOP | Gravity.LEFT);
        topParams.leftMargin = railWidth;
        shell.addView(top, topParams);

        LinearLayout titleGroup = new LinearLayout(this);
        titleGroup.setOrientation(LinearLayout.VERTICAL);
        titleGroup.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(titleGroup, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        TextView title = shellText("DSI", 19f, Color.WHITE);
        titleGroup.addView(title);
        TextView subtitle = shellText("Dimensional Singularity Intelligence", 10f, GOLD);
        titleGroup.addView(subtitle);
        TextView login = shellButton("登录", true);
        login.setOnClickListener(v -> runPageAction("登录|log in"));
        top.addView(login, new LinearLayout.LayoutParams(92, 50));
        TextView register = shellButton("注册", false);
        register.setOnClickListener(v -> runPageAction("注册|sign up"));
        LinearLayout.LayoutParams registerParams = new LinearLayout.LayoutParams(112, 50);
        registerParams.leftMargin = 10;
        top.addView(register, registerParams);

        FrameLayout composerLayer = new FrameLayout(this);
        composerLayer.setBackgroundColor(Color.rgb(5, 5, 5));
        FrameLayout.LayoutParams composerLayerParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, composerHeight, Gravity.BOTTOM | Gravity.LEFT);
        composerLayerParams.leftMargin = railWidth;
        shell.addView(composerLayer, composerLayerParams);

        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(8, 6, 8, 6);
        composer.setBackground(rounded(Color.rgb(31, 31, 31), Color.rgb(62, 62, 62), 28));
        FrameLayout.LayoutParams composerParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, Math.max(68, composerHeight - 22));
        composerParams.leftMargin = 18;
        composerParams.rightMargin = 18;
        composerParams.topMargin = 5;
        composerLayer.addView(composer, composerParams);

        TextView plus = shellText("+", 30f, Color.WHITE);
        plus.setGravity(Gravity.CENTER);
        plus.setOnClickListener(v -> runPageAction("attach|上传|image"));
        composer.addView(plus, new LinearLayout.LayoutParams(58,
                LinearLayout.LayoutParams.MATCH_PARENT));

        EditText input = new EditText(this);
        input.setHint("询问 DSI");
        input.setHintTextColor(Color.rgb(170, 170, 170));
        input.setTextColor(Color.WHITE);
        input.setTextSize(17f);
        input.setSingleLine(false);
        input.setMaxLines(3);
        input.setPadding(0, 0, 0, 0);
        input.setBackgroundColor(Color.TRANSPARENT);
        composer.addView(input, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        TextView microphone = shellText("◌", 26f, Color.WHITE);
        microphone.setGravity(Gravity.CENTER);
        microphone.setOnClickListener(v -> runPageAction("voice|语音|microphone"));
        composer.addView(microphone, new LinearLayout.LayoutParams(58,
                LinearLayout.LayoutParams.MATCH_PARENT));

        TextView send = shellButton("↑", false);
        send.setTextSize(23f);
        send.setOnClickListener(v -> sendNativeMessage(input));
        composer.addView(send, new LinearLayout.LayoutParams(58,
                LinearLayout.LayoutParams.MATCH_PARENT));
    }

    private void addRailIcon(LinearLayout rail, String glyph, View.OnClickListener listener) {
        TextView icon = shellText(glyph, 25f, Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        icon.setOnClickListener(listener);
        rail.addView(icon, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 64));
    }

    private TextView shellText(String text, float size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private TextView shellButton(String text, boolean light) {
        TextView view = shellText(text, 15f, light ? Color.BLACK : Color.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setBackground(rounded(light ? Color.WHITE : Color.rgb(38, 38, 38),
                light ? Color.WHITE : Color.rgb(78, 78, 78), 28));
        return view;
    }

    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(1, stroke);
        return drawable;
    }

    private void runPageAction(String pattern) {
        if (webView == null) return;
        String js = "(function(){var re=new RegExp(" + JSONObject.quote(pattern)
                + ",'i');var a=document.querySelectorAll('button,a,[role=button]');"
                + "for(var i=0;i<a.length;i++){var e=a[i],r=e.getBoundingClientRect();"
                + "var t=((e.innerText||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||''));"
                + "if(r.width>0&&r.height>0&&re.test(t)){e.click();break;}}})()";
        webView.evaluateJavascript(js, null);
    }

    private void sendNativeMessage(EditText input) {
        String message = input.getText().toString().trim();
        if (message.isEmpty() || webView == null) return;
        String js = "(function(){var v=" + JSONObject.quote(message) + ";"
                + "var q=[].slice.call(document.querySelectorAll('textarea,[contenteditable=\\\"true\\\"]')).find(function(e){"
                + "var r=e.getBoundingClientRect(),s=((e.getAttribute('placeholder')||'')+' '+(e.getAttribute('aria-label')||''));"
                + "return r.width>200&&r.height>8&&r.bottom>0&&r.top<innerHeight&&!/hidden/i.test(s);});"
                + "if(!q)return; q.focus();"
                + "if(q.tagName==='TEXTAREA'){var set=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;set.call(q,v);}"
                + "else{document.execCommand('insertText',false,v);}"
                + "q.dispatchEvent(new Event('input',{bubbles:true}));"
                + "setTimeout(function(){var b=[].slice.call(document.querySelectorAll('button')).find(function(e){var r=e.getBoundingClientRect(),t=((e.getAttribute('aria-label')||'')+' '+(e.innerText||''));return r.width>0&&r.height>0&&/send|发送/i.test(t);});if(b)b.click();},120);})()";
        webView.evaluateJavascript(js, null);
        input.setText("");
    }

    private void showError(String title, Throwable error) {
        String detail = error.getClass().getSimpleName();
        if (error.getMessage() != null && !error.getMessage().isEmpty()) {
            detail += "\n" + error.getMessage();
        }
        showErrorText(title + "\n\n" + detail);
    }

    private void showErrorText(String text) {
        root.removeAllViews();
        TextView message = new TextView(this);
        message.setText(text);
        message.setTextColor(GOLD);
        message.setTextSize(15f);
        message.setGravity(Gravity.CENTER);
        message.setPadding(32, 32, 32, 32);
        message.setBackgroundColor(BG);
        root.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.destroy();
            } catch (Throwable ignored) {
            }
            webView = null;
        }
        super.onDestroy();
    }
}
