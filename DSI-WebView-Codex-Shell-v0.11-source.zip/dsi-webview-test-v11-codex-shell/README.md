# DSI WebView Test 0.11 Codex Shell

这是 DSI 专属浏览器的横屏 Codex 风格桌面布局测试，不包含 DSI 启动动画，也不修改官方 ChatGPT APK。

## 当前行为

- Activity 固定为横屏，首屏只启动原生 Activity，不创建 WebView；点击按钮后才创建 WebView 并打开 `https://chatgpt.com/`。
- WebView 使用桌面版 Chrome User-Agent 和宽视口设置，优先请求 ChatGPT 的电脑网页布局。
- Android 外壳负责 DSI 顶栏、可展开/收缩的 Codex 式侧栏、登录按钮和紧凑提问框；中间区域仍由真实 ChatGPT WebView 渲染。
- WebView 注入布局脚本会隐藏网页自身的侧栏、顶部栏和原提问框，避免出现两个输入框；真实网页输入元素仍保留在 DOM 中用于发送消息。
- 外壳输入框会把文字转交给网页输入框，不读取账号信息、密码或 Cookie。
- 隐藏应用工具栏，并请求 Android 沉浸式全屏。
- 使用 Android System WebView 的真实网页渲染，不伪造聊天界面。
- 登录/注册相关页面不注入测试 CSS。
- 普通页面注入布局清理和暗色背景 CSS，用于验证真实网页排版改造可行性。
- 没有 `addJavascriptInterface`、账号密码读取、Cookie 读取、网络代理或 TLS 绕过。
- SSL 证书错误直接取消；清除文本流量被禁用。
- 支持网页文件选择器，供后续验证 ChatGPT 文件上传。
- 不申请相机、麦克风等原生权限。

这是 Java-only APK，没有额外的 ARM 原生库；Android ARM64 设备可直接运行。网页引擎由设备上的 Android System WebView 提供。

## 构建

GitHub Actions 工作流会使用 Java 17、Gradle 8.9 和 Android SDK 35 构建 `app-debug.apk`，并上传名为 `DSI-WebView-Codex-Shell-v0.11` 的 Artifact。工作流只在 Actions 中手动运行，避免每次提交重复建造。
