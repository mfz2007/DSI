package com.dsi.webviewtest;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

/** Landscape desktop-layout WebView diagnostic. */
public final class MainActivity extends Activity {
    private static final String START_URL = "https://chatgpt.com/";
    private static final String DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36";
    /**
     * Cleans up the real ChatGPT DOM behind the native DSI shell.  The old
     * version only clicked the sidebar button, leaving ChatGPT's own composer
     * visible underneath the native composer.  This script deliberately keeps
     * the real input in the DOM (so React still receives input events), but
     * moves the original visual shell out of the way and hides its chrome.
     */
    private static final String WEB_LAYOUT_SCRIPT = """
            (function () {
              if (window.__dsiWebLayoutV11) return;
              window.__dsiWebLayoutV11 = true;

              function mark(el, name) {
                if (el) el.setAttribute(name, '1');
              }

              function textOf(el) {
                return ((el.getAttribute && (el.getAttribute('placeholder') || '')) + ' ' +
                        (el.getAttribute && (el.getAttribute('data-placeholder') || '')) + ' ' +
                        (el.getAttribute && (el.getAttribute('aria-label') || '')) + ' ' +
                        (el.innerText || '')).toLowerCase();
              }

              function findInput() {
                var marked = document.querySelector('[data-dsi-chat-input="1"]');
                if (marked) return marked;
                var all = Array.from(document.querySelectorAll(
                    'textarea,[contenteditable="true"],input[placeholder]'));
                var best = null;
                var bestWidth = 0;
                all.forEach(function (el) {
                  var r = el.getBoundingClientRect();
                  var t = textOf(el);
                  if (/ask|message|prompt|询问|聊天|chatgpt/.test(t) && r.width > bestWidth) {
                    best = el;
                    bestWidth = r.width;
                  }
                });
                if (best) return best;
                all.forEach(function (el) {
                  var r = el.getBoundingClientRect();
                  if (r.width > bestWidth && r.width > innerWidth * .25 && r.height > 8) {
                    best = el;
                    bestWidth = r.width;
                  }
                });
                return best;
              }

              function hideOriginalComposer() {
                var input = findInput();
                if (!input) return;
                mark(input, 'data-dsi-chat-input');
                var parent = input;
                for (var i = 0; i < 10 && parent; i++, parent = parent.parentElement) {
                  var r = parent.getBoundingClientRect();
                  if (i > 0 && parent.tagName !== 'BODY' && parent.tagName !== 'HTML' &&
                      r.width > innerWidth * .35 && r.height > 56 &&
                      r.height < innerHeight * .45 && r.bottom > innerHeight * .38) {
                    mark(parent, 'data-dsi-original-composer');
                    parent.style.setProperty('opacity', '0', 'important');
                    parent.style.setProperty('pointer-events', 'none', 'important');
                    parent.style.setProperty('position', 'absolute', 'important');
                    parent.style.setProperty('left', '-10000px', 'important');
                    parent.style.setProperty('bottom', '-1000px', 'important');
                    break;
                  }
                }
              }

              function hideChrome() {
                var candidates = document.querySelectorAll(
                    'nav,aside,[role="navigation"],header,[role="banner"],'
                    + '[data-testid*="sidebar"],[data-testid*="header"],'
                    + '[class*="sidebar"],[class*="Sidebar"],[class*="header"],[class*="Header"]');
                candidates.forEach(function (el) {
                  var r = el.getBoundingClientRect();
                  if ((r.left <= 12 && r.width > 150 && r.height > innerHeight * .35) ||
                      (r.top <= 12 && r.width > innerWidth * .45 && r.height < 130)) {
                    mark(el, 'data-dsi-original-chrome');
                    el.style.setProperty('opacity', '0', 'important');
                    el.style.setProperty('pointer-events', 'none', 'important');
                  }
                });
              }

              function installStyle() {
                var style = document.getElementById('dsi-web-layout-v11');
                if (!style) {
                  style = document.createElement('style');
                  style.id = 'dsi-web-layout-v11';
                  (document.head || document.documentElement).appendChild(style);
                }
                style.textContent =
                    'html,body{background:#000!important;overflow:hidden!important;}' +
                    '[data-dsi-original-composer="1"]{visibility:visible!important;}' +
                    '[data-dsi-original-chrome="1"]{background:transparent!important;}';
              }

              function apply() {
                installStyle();
                hideChrome();
                hideOriginalComposer();
              }

              apply();
              [350, 900, 1800, 3200].forEach(function (delay) {
                setTimeout(apply, delay);
              });
              window.addEventListener('resize', apply);
              if (document.body) {
                var pending = false;
                new MutationObserver(function () {
                  if (pending) return;
                  pending = true;
                  requestAnimationFrame(function () {
                    pending = false;
                    apply();
                  });
                }).observe(document.body, {childList: true, subtree: true});
              }
            })();
            """;

    private static final int GOLD = Color.rgb(208, 168, 92);
    private static final int BG = Color.rgb(9, 12, 11);
    private FrameLayout root;
    private WebView webView;
    private FrameLayout nativeShell;
    private LinearLayout nativeRail;
    private LinearLayout nativeTop;
    private FrameLayout nativeComposerLayer;
    private LinearLayout nativeBrandGroup;
    private final java.util.ArrayList<TextView> nativeNavLabels = new java.util.ArrayList<>();
    private int expandedRailWidth;
    private int collapsedRailWidth;
    private int nativeTopHeight;
    private int nativeComposerHeight;
    private boolean shellExpanded = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        setContentView(root);
        try {
            configureWindow();
            showNativeScreen();
        } catch (Throwable error) {
            showError("原生 Activity 启动异常", error);
        }
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.BLACK);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        hideSystemBars();
    }

    private void hideSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void showNativeScreen() {
        root.removeAllViews();
        FrameLayout panel = new FrameLayout(this);
        panel.setBackgroundColor(BG);

        TextView status = new TextView(this);
        status.setText("DSI WebView Test 0.11.0\n\nDSI Codex 桌面布局测试\n尚未创建 WebView");
        status.setTextColor(GOLD);
        status.setTextSize(16f);
        status.setGravity(Gravity.CENTER);
        status.setPadding(32, 32, 32, 32);
        panel.addView(status, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        Button start = new Button(this);
        start.setText("创建 WebView 并加载 ChatGPT");
        start.setOnClickListener(v -> launchWebView());
        FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        buttonParams.bottomMargin = 72;
        panel.addView(start, buttonParams);
        root.addView(panel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private void launchWebView() {
        try {
            root.removeAllViews();
            webView = new WebView(this);
            webView.setBackgroundColor(BG);
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            // Ask ChatGPT to render its desktop layout instead of the narrow
            // Android WebView layout. The Activity itself is locked to landscape.
            settings.setUserAgentString(DESKTOP_USER_AGENT);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(false);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(true);
            settings.setSupportMultipleWindows(false);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (url != null && url.startsWith("https://chatgpt.com")) {
                        applyDesktopLayout(view);
                        view.postDelayed(() -> applyDesktopLayout(view), 700L);
                        view.postDelayed(() -> applyDesktopLayout(view), 1800L);
                        view.postDelayed(() -> applyDesktopLayout(view), 3500L);
                    }
                }

                @Override
                public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                    try {
                        root.removeView(view);
                        view.destroy();
                    } catch (Throwable ignored) {
                    }
                    showErrorText("WebView 渲染进程退出\n请记录这句话和手机型号");
                    return true;
                }
            });
            root.addView(webView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            root.post(this::buildNativeShell);
            webView.loadUrl("about:blank");
            webView.postDelayed(() -> {
                if (webView != null) webView.loadUrl(START_URL);
            }, 500L);
        } catch (Throwable error) {
            showError("WebView 创建或初始化异常", error);
        }
    }

    private void applyDesktopLayout(WebView view) {
        try {
            view.evaluateJavascript(WEB_LAYOUT_SCRIPT, null);
        } catch (Throwable ignored) {
        }
    }

    private void buildNativeShell() {
        if (root.findViewWithTag("dsi-native-shell") != null) return;
        int width = root.getWidth();
        int height = root.getHeight();
        if (width < 400 || height < 240) {
            root.post(this::buildNativeShell);
            return;
        }

        expandedRailWidth = Math.max(dp(300), Math.round(width * 0.32f));
        collapsedRailWidth = Math.max(dp(82), Math.round(width * 0.065f));
        nativeTopHeight = Math.max(dp(68), Math.round(height * 0.12f));
        nativeComposerHeight = Math.max(dp(88), Math.round(height * 0.15f));

        nativeShell = new FrameLayout(this);
        nativeShell.setTag("dsi-native-shell");
        nativeShell.setClickable(false);
        root.addView(nativeShell, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        nativeRail = new LinearLayout(this);
        nativeRail.setOrientation(LinearLayout.VERTICAL);
        nativeRail.setBackgroundColor(Color.BLACK);
        nativeRail.setPadding(dp(12), 0, dp(12), 0);
        FrameLayout.LayoutParams railParams = new FrameLayout.LayoutParams(
                expandedRailWidth, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.LEFT | Gravity.TOP);
        nativeShell.addView(nativeRail, railParams);

        LinearLayout railHeader = new LinearLayout(this);
        railHeader.setOrientation(LinearLayout.HORIZONTAL);
        railHeader.setGravity(Gravity.CENTER_VERTICAL);
        nativeRail.addView(railHeader, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, nativeTopHeight));

        nativeBrandGroup = new LinearLayout(this);
        nativeBrandGroup.setOrientation(LinearLayout.VERTICAL);
        nativeBrandGroup.setGravity(Gravity.CENTER_VERTICAL);
        railHeader.addView(nativeBrandGroup, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        TextView railBrand = shellText("DSI", 25f, Color.WHITE);
        nativeBrandGroup.addView(railBrand);
        TextView railSubtitle = shellText("Dimensional Singularity Intelligence", 10f, GOLD);
        nativeBrandGroup.addView(railSubtitle);

        TextView collapse = shellText("▣", 22f, Color.WHITE);
        collapse.setGravity(Gravity.CENTER);
        collapse.setOnClickListener(v -> setShellExpanded(!shellExpanded));
        railHeader.addView(collapse, new LinearLayout.LayoutParams(dp(54),
                LinearLayout.LayoutParams.MATCH_PARENT));

        addNavItem("✎", "新聊天", v -> runPageAction("new chat|新聊天"), true);
        addNavItem("▧", "图像", v -> runPageAction("image|图像"), false);
        addNavItem("⊙", "插件", v -> runPageAction("plugin|插件"), false);
        addNavItem("⌁", "深度研究", v -> runPageAction("deep research|深度研究"), false);
        addNavItem("◇", "查看套餐和定价", v -> runPageAction("pricing|套餐|定价"), false);
        addNavItem("◎", "帮助", v -> runPageAction("help|帮助"), false);
        LinearLayout.LayoutParams railSpacer = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        nativeRail.addView(new View(this), railSpacer);
        addNavItem("⚙", "设置", v -> runPageAction("settings|设置"), false);

        nativeTop = new LinearLayout(this);
        nativeTop.setOrientation(LinearLayout.HORIZONTAL);
        nativeTop.setGravity(Gravity.CENTER_VERTICAL);
        nativeTop.setPadding(dp(24), 0, dp(18), 0);
        nativeTop.setBackgroundColor(Color.BLACK);
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, nativeTopHeight, Gravity.TOP | Gravity.LEFT);
        topParams.leftMargin = expandedRailWidth;
        nativeShell.addView(nativeTop, topParams);

        LinearLayout titleGroup = new LinearLayout(this);
        titleGroup.setOrientation(LinearLayout.VERTICAL);
        titleGroup.setGravity(Gravity.CENTER_VERTICAL);
        nativeTop.addView(titleGroup, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        TextView title = shellText("DSI", 18f, Color.WHITE);
        titleGroup.addView(title);
        TextView subtitle = shellText("Dimensional Singularity Intelligence", 10f, GOLD);
        titleGroup.addView(subtitle);
        TextView login = shellButton("登录", true);
        login.setOnClickListener(v -> runPageAction("登录|log in"));
        nativeTop.addView(login, new LinearLayout.LayoutParams(dp(92), dp(50)));
        TextView register = shellButton("注册", false);
        register.setOnClickListener(v -> runPageAction("注册|sign up"));
        LinearLayout.LayoutParams registerParams = new LinearLayout.LayoutParams(112, 50);
        registerParams.width = dp(112);
        registerParams.height = dp(50);
        registerParams.leftMargin = dp(10);
        nativeTop.addView(register, registerParams);

        nativeComposerLayer = new FrameLayout(this);
        nativeComposerLayer.setBackgroundColor(Color.BLACK);
        FrameLayout.LayoutParams composerLayerParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, nativeComposerHeight, Gravity.BOTTOM | Gravity.LEFT);
        composerLayerParams.leftMargin = expandedRailWidth;
        nativeShell.addView(nativeComposerLayer, composerLayerParams);

        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(6), dp(5), dp(6), dp(5));
        composer.setBackground(rounded(Color.rgb(31, 31, 31), Color.rgb(62, 62, 62), 26));
        FrameLayout.LayoutParams composerParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, Math.max(dp(64), nativeComposerHeight - dp(24)));
        composerParams.leftMargin = dp(18);
        composerParams.rightMargin = dp(18);
        composerParams.topMargin = dp(7);
        nativeComposerLayer.addView(composer, composerParams);

        TextView plus = shellText("+", 30f, Color.WHITE);
        plus.setGravity(Gravity.CENTER);
        plus.setOnClickListener(v -> runPageAction("attach|上传|image"));
        composer.addView(plus, new LinearLayout.LayoutParams(dp(58),
                LinearLayout.LayoutParams.MATCH_PARENT));

        EditText input = new EditText(this);
        input.setHint("询问 DSI");
        input.setHintTextColor(Color.rgb(170, 170, 170));
        input.setTextColor(Color.WHITE);
        input.setTextSize(17f);
        input.setSingleLine(false);
        input.setMaxLines(3);
        input.setPadding(0, 0, 0, 0);
        input.setBackgroundColor(Color.TRANSPARENT);
        composer.addView(input, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        TextView microphone = shellText("◌", 26f, Color.WHITE);
        microphone.setGravity(Gravity.CENTER);
        microphone.setOnClickListener(v -> runPageAction("voice|语音|microphone"));
        composer.addView(microphone, new LinearLayout.LayoutParams(dp(58),
                LinearLayout.LayoutParams.MATCH_PARENT));

        TextView send = shellButton("↑", false);
        send.setTextSize(23f);
        send.setOnClickListener(v -> sendNativeMessage(input));
        composer.addView(send, new LinearLayout.LayoutParams(dp(58),
                LinearLayout.LayoutParams.MATCH_PARENT));

        updateShellBounds();
    }

    private void addNavItem(String glyph, String label, View.OnClickListener listener, boolean selected) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(10), 0, dp(10), 0);
        item.setBackground(selected ? rounded(Color.rgb(64, 64, 64), Color.rgb(64, 64, 64), 14)
                : rounded(Color.TRANSPARENT, Color.TRANSPARENT, 14));
        item.setOnClickListener(listener);
        nativeRail.addView(item, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64)));

        TextView icon = shellText(glyph, 25f, Color.WHITE);
        icon.setGravity(Gravity.CENTER);
        item.addView(icon, new LinearLayout.LayoutParams(dp(52),
                LinearLayout.LayoutParams.MATCH_PARENT));

        TextView text = shellText(label, 17f, Color.WHITE);
        text.setGravity(Gravity.CENTER_VERTICAL);
        nativeNavLabels.add(text);
        item.addView(text, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));
    }

    private void setShellExpanded(boolean expanded) {
        shellExpanded = expanded;
        updateShellBounds();
        if (nativeBrandGroup != null) {
            nativeBrandGroup.setVisibility(expanded ? View.VISIBLE : View.GONE);
        }
        for (TextView label : nativeNavLabels) {
            label.setVisibility(expanded ? View.VISIBLE : View.GONE);
        }
    }

    private void updateShellBounds() {
        if (nativeShell == null) return;
        int railWidth = shellExpanded ? expandedRailWidth : collapsedRailWidth;

        FrameLayout.LayoutParams railParams = (FrameLayout.LayoutParams) nativeRail.getLayoutParams();
        railParams.width = railWidth;
        nativeRail.setLayoutParams(railParams);

        FrameLayout.LayoutParams topParams = (FrameLayout.LayoutParams) nativeTop.getLayoutParams();
        topParams.leftMargin = railWidth;
        nativeTop.setLayoutParams(topParams);

        FrameLayout.LayoutParams composerParams = (FrameLayout.LayoutParams) nativeComposerLayer.getLayoutParams();
        composerParams.leftMargin = railWidth;
        nativeComposerLayer.setLayoutParams(composerParams);

        if (webView != null) {
            FrameLayout.LayoutParams webParams = (FrameLayout.LayoutParams) webView.getLayoutParams();
            webParams.leftMargin = railWidth;
            webParams.topMargin = nativeTopHeight;
            webParams.bottomMargin = nativeComposerHeight;
            webView.setLayoutParams(webParams);
            webView.postDelayed(() -> applyDesktopLayout(webView), 120L);
        }
    }

    private TextView shellText(String text, float size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView shellButton(String text, boolean light) {
        TextView view = shellText(text, 15f, light ? Color.BLACK : Color.WHITE);
        view.setGravity(Gravity.CENTER);
        view.setBackground(rounded(light ? Color.WHITE : Color.rgb(38, 38, 38),
                light ? Color.WHITE : Color.rgb(78, 78, 78), 28));
        return view;
    }

    private GradientDrawable rounded(int fill, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(1, stroke);
        return drawable;
    }

    private void runPageAction(String pattern) {
        if (webView == null) return;
        String js = "(function(){var re=new RegExp(" + JSONObject.quote(pattern)
                + ",'i');var a=document.querySelectorAll('button,a,[role=button]');"
                + "for(var i=0;i<a.length;i++){var e=a[i],r=e.getBoundingClientRect();"
                + "var t=((e.innerText||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||''));"
                + "if(r.width>0&&r.height>0&&re.test(t)){e.click();break;}}})()";
        webView.evaluateJavascript(js, null);
    }

    private void sendNativeMessage(EditText input) {
        String message = input.getText().toString().trim();
        if (message.isEmpty() || webView == null) return;
        String js = "(function(){var v=" + JSONObject.quote(message) + ";"
                + "var q=document.querySelector('[data-dsi-chat-input=\\\"1\\\"]');"
                + "if(!q)q=[].slice.call(document.querySelectorAll('textarea,[contenteditable=\\\"true\\\"]')).find(function(e){"
                + "var r=e.getBoundingClientRect(),s=((e.getAttribute('placeholder')||'')+' '+(e.getAttribute('aria-label')||''));"
                + "return /ask|message|prompt|询问|聊天|chatgpt/i.test(s)||r.width>200;});"
                + "if(!q)return; q.focus();"
                + "if(q.tagName==='TEXTAREA'){var set=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;set.call(q,v);}"
                + "else{document.execCommand('insertText',false,v);}"
                + "q.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:v}));"
                + "setTimeout(function(){var b=[].slice.call(document.querySelectorAll('button,[role=button]')).find(function(e){var t=((e.getAttribute('aria-label')||'')+' '+(e.innerText||'')+' '+(e.getAttribute('data-testid')||''));return /send|发送|submit/i.test(t);});if(b)b.click();},180);})()";
        webView.evaluateJavascript(js, null);
        input.setText("");
    }

    private void showError(String title, Throwable error) {
        String detail = error.getClass().getSimpleName();
        if (error.getMessage() != null && !error.getMessage().isEmpty()) {
            detail += "\n" + error.getMessage();
        }
        showErrorText(title + "\n\n" + detail);
    }

    private void showErrorText(String text) {
        root.removeAllViews();
        TextView message = new TextView(this);
        message.setText(text);
        message.setTextColor(GOLD);
        message.setTextSize(15f);
        message.setGravity(Gravity.CENTER);
        message.setPadding(32, 32, 32, 32);
        message.setBackgroundColor(BG);
        root.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.destroy();
            } catch (Throwable ignored) {
            }
            webView = null;
        }
        super.onDestroy();
    }
}
