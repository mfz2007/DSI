# DSI WebView Login Test 0.13

这是一个只用于验证登录链路的最小 Android WebView APK。它直接打开真实的 https://chatgpt.com/，不注入 DSI/Codex CSS，不显示自制聊天外壳，也不修改登录页面。

## 这版做什么

- Android 16 / ARM64 可运行；Activity 固定横屏并隐藏系统栏。
- 使用 Android System WebView 加载真实 ChatGPT 网页。
- 开启网页登录需要的 JavaScript、DOM Storage 和正常 WebView 会话存储。
- 使用系统 WebView 的普通 Cookie 存储来保持登录会话；应用不会读取、记录、导出或注入 Cookie。
- 不读取密码、验证码、账号信息，不创建 JavaScript bridge，不改登录页。
- 保持正常 TLS 验证；禁止明文网络和混合内容，不提供 SSL 错误绕过。
- 不包含 DSI 启动动画、CSS 排版、原生聊天输入框或网络代理。

## 手机上怎么测试

1. 在 GitHub Actions 运行 Build DSI WebView Login Test v0.13。
2. 下载 Artifact 中的 app-debug.apk 并安装。
3. 打开后等待 chatgpt.com 登录页。
4. 手动完成登录；不要把密码、验证码或恢复码发给任何人。
5. 登录成功的标准是回到 ChatGPT 聊天主页，并能看到自己的正常会话。
6. 退出应用后重新打开一次：如果仍在聊天主页，说明 WebView 会话持久化也通过。

如果页面空白、反复跳转、提示不支持浏览器或登录后回不到聊天主页，请记录页面上的原文和手机截图。这一版没有 CSS 干预，因此可以把问题定位到 WebView、网络或站点认证兼容性。

## 构建

工作流使用 Java 17、Gradle 8.9 和 Android SDK 35，在 GitHub Actions 中手动构建 app-debug.apk，然后上传单个 Artifact。项目不包含 Gradle 缓存或构建产物。

