package com.dsi.webviewtest;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

/**
 * Minimal DSI WebView probe.
 *
 * The app deliberately has no JavaScript bridge, no cookie reads, no account
 * handling, and no TLS override. JavaScript is enabled only because the real
 * ChatGPT web application requires it.
 */
public final class MainActivity extends Activity {
    private static final String START_URL = "https://chatgpt.com/";
    private static final int FILE_CHOOSER_REQUEST = 1001;

    // This is intentionally a small visual probe, not a ChatGPT re-theme.
    // It is never injected into known login/auth pages.
    private static final String GOLD_CSS_SCRIPT =
            "(function(){"
                    + "if(!document.head)return;"
                    + "var s=document.getElementById('dsi-gold-test-style');"
                    + "if(!s){s=document.createElement('style');s.id='dsi-gold-test-style';document.head.appendChild(s);}"
                    + "s.textContent=':root{--dsi-gold:#D0A85C;}"
                    + "body{background:#090C0B!important;}"
                    + "body :is(h1,h2,h3,h4,p,span,button,textarea,input,[role=\\\"button\\\"]){color:var(--dsi-gold)!important;}"
                    + "textarea,input{caret-color:var(--dsi-gold)!important;}';"
                    + "})();";

    private WebView webView;
    private FrameLayout root;
    private ValueCallback<Uri[]> pendingFileCallback;
    private int rendererRecoveryAttempts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();

        root = new FrameLayout(this);
        webView = createWebView();
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (savedInstanceState == null) {
            webView.loadUrl(START_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void configureWindow() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.BLACK);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        hideSystemBars();
    }

    private void hideSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemBars();
        }
    }

    private WebView createWebView() {
        WebView created = new WebView(this);
        created.setBackgroundColor(Color.rgb(9, 12, 11));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            created.setRendererPriorityPolicy(
                    WebView.RENDERER_PRIORITY_BOUND, true);
        }

        WebSettings settings = created.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        created.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                // Keep normal HTTPS navigation inside the WebView. Do not
                // silently downgrade to cleartext or handle intent:// URLs.
                return scheme != null && !"https".equalsIgnoreCase(scheme);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!isLoginOrAuthPage(url)) {
                    view.evaluateJavascript(GOLD_CSS_SCRIPT, null);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // Never continue through a certificate error.
                handler.cancel();
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // A WebView whose renderer exited is permanently unusable.
                // Remove and destroy that instance before creating a new one;
                // calling loadUrl() on the old instance can crash the app.
                recoverFromRendererExit(view);
                return true;
            }
        });

        created.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                }
                pendingFileCallback = filePathCallback;
                try {
                    startActivityForResult(
                            fileChooserParams.createIntent(), FILE_CHOOSER_REQUEST);
                } catch (Exception ignored) {
                    pendingFileCallback = null;
                    filePathCallback.onReceiveValue(null);
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // No camera/microphone/native permission bridge in this probe.
                request.deny();
            }
        });
        return created;
    }

    private void recoverFromRendererExit(WebView deadView) {
        if (deadView != webView || root == null) {
            return;
        }
        root.removeView(deadView);
        deadView.setWebChromeClient(null);
        deadView.setWebViewClient(null);
        deadView.destroy();
        webView = null;

        if (rendererRecoveryAttempts++ >= 1) {
            showRendererRecoveryMessage();
            return;
        }

        root.postDelayed(() -> {
            if (isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1
                    && isDestroyed())) {
                return;
            }
            webView = createWebView();
            root.addView(webView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            webView.loadUrl(START_URL);
        }, 250L);
    }

    private void showRendererRecoveryMessage() {
        TextView message = new TextView(this);
        message.setText("WebView 渲染进程退出\n请更新 Android System WebView 后重试");
        message.setTextColor(Color.rgb(208, 168, 92));
        message.setTextSize(16f);
        message.setGravity(android.view.Gravity.CENTER);
        message.setBackgroundColor(Color.rgb(9, 12, 11));

        Button retry = new Button(this);
        retry.setText("重试");
        retry.setOnClickListener(v -> {
            rendererRecoveryAttempts = 0;
            root.removeAllViews();
            webView = createWebView();
            root.addView(webView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
            webView.loadUrl(START_URL);
        });

        FrameLayout recovery = new FrameLayout(this);
        recovery.setBackgroundColor(Color.rgb(9, 12, 11));
        recovery.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams retryParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.BOTTOM);
        retryParams.bottomMargin = 72;
        recovery.addView(retry, retryParams);
        root.addView(recovery, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private static boolean isLoginOrAuthPage(String rawUrl) {
        try {
            Uri uri = Uri.parse(rawUrl);
            String host = uri.getHost();
            String path = uri.getPath();
            String lowerHost = host == null ? "" : host.toLowerCase(Locale.US);
            String lowerPath = path == null ? "" : path.toLowerCase(Locale.US);
            if ("auth.openai.com".equals(lowerHost)
                    || lowerHost.endsWith(".auth.openai.com")) {
                return true;
            }
            return lowerPath.contains("/login")
                    || lowerPath.contains("/signup")
                    || lowerPath.contains("/auth");
        } catch (Exception ignored) {
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && pendingFileCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            pendingFileCallback.onReceiveValue(results);
            pendingFileCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
